<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FunnelStep extends Model
{
    public $timestamps = false;
}
