<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubscriptionItem extends Model
{
    public $timestamps = false;
    protected $guarded = [];
}
