<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class P1Validity extends Model
{
    use HasFactory;
    protected $table = 'p1_validity';
}
