<?php

use Illuminate\Database\Seeder;
use App\AgentCalendarSetting;

class AgentCalendarSettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        AgentCalendarSetting::create([
            'user_id' => 1
        ]);

        AgentCalendarSetting::create([
            'user_id' => 2
        ]);

        AgentCalendarSetting::create([
            'user_id' => 3
        ]);

		AgentCalendarSetting::create([
            'user_id' => 4
        ]);

		AgentCalendarSetting::create([
            'user_id' => 5
        ]);

		AgentCalendarSetting::create([
            'user_id' => 6
        ]);

		AgentCalendarSetting::create([
            'user_id' => 8
        ]);

		AgentCalendarSetting::create([
            'user_id' => 9
        ]);

		AgentCalendarSetting::create([
            'user_id' => 10
        ]);

		AgentCalendarSetting::create([
            'user_id' => 11
        ]);

		AgentCalendarSetting::create([
            'user_id' => 12
        ]);

		AgentCalendarSetting::create([
            'user_id' => 13
        ]);

		AgentCalendarSetting::create([
            'user_id' => 14
        ]);

		AgentCalendarSetting::create([
            'user_id' => 15
        ]);

		AgentCalendarSetting::create([
            'user_id' => 16
        ]);

		AgentCalendarSetting::create([
            'user_id' => 17
        ]);
    }
}
