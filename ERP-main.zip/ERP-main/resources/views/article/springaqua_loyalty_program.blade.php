<div class="container py-4 article">
	<div class="row justify-content-md-center px-4">
		<div class="col-md-12">
			<h4 class="main-heading text-center mb-0"><a class="heading-breadcrumb" href="{{url("/faq")}}">FAQ's</a> > What is the software-demand.com Loyalty Program ?</h4>
		</div>
	</div>
	<div class="row justify-content-center py-4">
		<div class="col-md-12">
			<div class="card card-container shadow-sm mw-100">
				<div class="card-body">
					<article>
						<p class="name mt-4">What is the software-demand.com Loyalty Program ?</p>
						<div class="description">
							<p>The software-demand.com Loyalty Program offers customers the opportunity to set up the auto-renewal for their filters and receive a 10% discount on  all filters and shower filter renewals.</p>
						</div>
					</article>
				</div>
			</div>
		</div>
	</div>
</div>
