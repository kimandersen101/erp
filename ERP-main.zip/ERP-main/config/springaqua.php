<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Hashids (A PHP library)
    |--------------------------------------------------------------------------
    |
    | Hashids is a small open-source library that generates short, unique,
    | non-sequential ids from numbers. This value is the 'salt' for hashdis
    | to generate unique ids. This 'salt' must be same in all our projects wherever
    | we want generated ids to be shared (encoded / decoded).
    |
    */

];
